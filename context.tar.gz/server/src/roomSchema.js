const storySchema = {
  type: 'object',
  properties: {
    id: {
      type: 'string',
      format: 'uuid'
    },
    title: {
      type: 'string',
      minLength: 1,
      maxLength: 100
    },
    description: {
      type: ['string', 'undefined', 'null'],
      minLength: 0,
      maxLength: 2000
    },
    key: {
      // This key is an optional field. It is set when importing from an external tool (e.g. Jira) via csv file. If the field is present in the csv file.
      // (This field is immutable, the changeStory command does not allow to modify it.)
      type: ['string', 'undefined', 'null'],
      minLength: 0,
      maxLength: 100
    },
    estimations: {
      type: 'object'
    },
    estimationsConfidence: {
      type: 'object'
    },
    createdAt: {
      type: 'number'
    },
    consensus: {
      type: ['number', 'undefined', 'null']
    },
    trashed: {
      type: 'boolean'
    },
    revealed: {
      type: 'boolean'
    },
    sortOrder: {
      type: ['number', 'undefined', 'null']
    }
  },
  required: ['id', 'title', 'createdAt'],
  additionalProperties: false
};

const userSchema = {
  type: 'object',
  properties: {
    id: {
      type: 'string',
      format: 'uuid'
    },
    username: {
      type: 'string',
      format: 'username'
    },
    email: {
      type: ['string', 'undefined', 'null'],
      format: 'email'
    },
    emailHash: {
      type: ['string', 'undefined', 'null']
    },
    avatar: {
      type: 'number'
    },
    disconnected: {
      type: 'boolean'
    },
    excluded: {
      type: 'boolean'
    }
  },
  required: ['id', 'avatar', 'username'],
  additionalProperties: false
};

const roomSchema = {
  properties: {
    id: {
      type: 'string',
      format: 'roomId'
    },
    selectedStory: {
      type: ['string', 'undefined', 'null'],
      format: 'uuid'
    },
    cardConfig: {
      type: ['array', 'undefined', 'null'],
      format: 'cardConfig'
    },
    stories: {
      type: 'array',
      items: storySchema
    },
    users: {
      type: 'array',
      items: userSchema
    },
    created: {
      type: 'number'
    },
    lastActivity: {
      type: 'number'
    },
    autoReveal: {
      type: 'boolean'
    },
    withConfidence: {
      type: 'boolean'
    },
    issueTrackingUrl: {
      type: ['string', 'undefined', 'null']
    },
    markedForDeletion: {
      type: 'boolean'
    },
    password: {
      type: 'object',
      properties: {
        hash: {
          type: 'string'
        },
        salt: {
          type: 'string'
        }
      },
      additionalProperties: false,
      required: ['hash', 'salt']
    }
  },
  required: ['id', 'stories', 'users', 'created', 'lastActivity', 'markedForDeletion'],
  additionalProperties: false
};

export default roomSchema;
