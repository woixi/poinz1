/**
 * a stories import (csv) failed. Does not modify room in any way,
 */
const importFailedEventHandler = (room) => ({...room});

export default importFailedEventHandler;
